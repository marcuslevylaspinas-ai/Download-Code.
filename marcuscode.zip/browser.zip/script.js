const cursor = document.getElementById('custom-cursor');
;
document.addEventListener('mousemove', (e) => {
    // This moves the div to your mouse position
    cursor.style.left = e.clientX + 'px';
    cursor.style.top = e.clientY + 'px';
});