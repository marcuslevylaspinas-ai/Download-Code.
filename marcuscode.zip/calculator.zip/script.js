function r() {
        // 1. Secret Codes
        if(s.value == '777') {
            s.value = "JACKPOT! 🎰";
            s.classList.add('jackpot');
        } else if (s.value == '1234') {
            s.value = "GAME MODE! 🎮";
            s.classList.add('game-mode');
        } else if (s.value == '0000') {
            s.value = "SYSTEM CRASH";
            b.classList.add('nuke');
        } else {
            try { 
                // 2. The Auto-Fixer: Clean up trailing operators like "5+-"
                let cleanedInput = s.value.replace(/[+\-*/]+$/, ""); 
                
                // 3. Calculation
                let result = eval(cleanedInput); 
                
                // 4. Check for NaN or Infinity
                if (isNaN(result) || !isFinite(result)) {
                    throw new Error("Invalid");
                }
                
                s.value = result; 
            } catch(e) { 
                s.value = "Error"; 
                b.classList.add('shake');
                setTimeout(()=> b.classList.remove('shake'), 300);
            }
        }
    }